// #include <string>

#include "processor.h"
#include "linux_parser.h"

// using std::string;

// TODO: Return the aggregate CPU utilization
float Processor::Utilization() { 
//  vector<string> cpuUtil;
//  cpuUtil[0] = LinuxParser::CpuUtilization();
//  float cpuUtilisation = std::stof(cpuUtil[0]);
    
//   return cpuUtilisation;
  
  return 0.0;
}