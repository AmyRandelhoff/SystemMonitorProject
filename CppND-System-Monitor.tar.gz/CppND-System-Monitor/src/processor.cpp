#include "processor.h"

#include <vector>
#include <string>

// TODO: Return the aggregate CPU utilization
float Processor::Utilization() { 
  std::vector<std::string> cpuJiffies = LinuxParser::CpuUtilization();
  
  float IdleJiffies = std::stof(cpuJiffies[3]) + std::stof(cpuJiffies[4]);
  float TotalJiffies;
  for (int i = 0; i < 9; i++) {
    TotalJiffies += std::stof(cpuJiffies[i]);
  }
  
  _cpuUtil = TotalJiffies - IdleJiffies;
  
  return _cpuUtil/TotalJiffies;
     
}