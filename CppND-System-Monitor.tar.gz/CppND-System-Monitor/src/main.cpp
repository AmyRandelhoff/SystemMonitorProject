#include "ncurses_display.h"
#include "system.h"
#include "linux_parser.h"

extern ofstream myfile;

int main() {
  System system;
  myfile.open ("example.txt");
 
   myfile  << "linux parser" << "\n";    
    myfile.flush();
  NCursesDisplay::Display(system);
  myfile.close();
}