#include "processor.h"

#include <vector>
#include <string>

// TODO: Return the aggregate CPU utilization
float Processor::Utilization() { 
  std::vector<std::string> cpuUtilisation = LinuxParser::CpuUtilization();
  _cpuUtil = std::stof(cpuUtilisation[0]);
  
  return _cpuUtil;
  
}