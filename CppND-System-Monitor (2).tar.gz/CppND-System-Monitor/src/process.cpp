#include <unistd.h>
#include <cctype>
#include <sstream>
#include <string>
#include <vector>

#include "process.h"

using std::string;
using std::to_string;
using std::vector;

Process::Process(int pid) {
  _pid = pid;
  _cmd = LinuxParser::Command(_pid);
  _memUtil = LinuxParser::Ram(_pid);
  _user = LinuxParser::User(_pid);
  _upt = LinuxParser::UpTime(_pid);
}

// TODO: Return this process's ID
int Process::Pid() { 
  return _pid;
}

// TODO: Return this process's CPU utilization
float Process::CpuUtilization() const { 
  // calculating system uptime
  string value;
  string line1;
  long uptime;
  std::ifstream stream1(LinuxParser::kProcDirectory + to_string(_pid) + LinuxParser::kStatFilename);
  if (stream1.is_open()) {
     std::getline(stream1, line1);
     std::istringstream linestream1(line1);
     for (int i = 0; i < 22; i++) { 
          linestream1 >> value;
     }  
  }
  uptime = stol(value, nullptr, 10);
  uptime / sysconf(_SC_CLK_TCK);
  
  // calculating ActiveJiffies
  long UTime;
  long STime;
  long CUTime;
  long CSTime;
  int i = 0;
  string line2;
  vector<string> values;
  std::ifstream stream2(LinuxParser::kProcDirectory + to_string(_pid) + LinuxParser::kStatFilename);
  if (stream2.is_open()) {
    std::getline(stream2, line2);
    std::istringstream linestream2(line2);
    while (linestream2) {
      linestream2 >> values[i];
      i++;
    }
  }
  UTime = stol(values[13], nullptr, 10);
  STime = stol(values[14], nullptr, 10);
  CUTime = stol(values[15], nullptr, 10);
  CSTime = stol(values[16], nullptr, 10);
  
  long ActiveJiffies = UTime + STime + CUTime + CSTime;
  
  // calculating the CPU utilisation
  return ActiveJiffies/uptime;
}

// TODO: Return the command that generated this process
string Process::Command() { 
  return _cmd;
}

// TODO: Return this process's memory utilization
string Process::Ram() { 
  return _memUtil;
}

// TODO: Return the user (name) that generated this process
string Process::User() { 
  return _user;
}

// TODO: Return the age of this process (in seconds)
long int Process::UpTime() { 
  return _upt;
}

// TODO: Overload the "less than" comparison operator for Process objects
// REMOVE: [[maybe_unused]] once you define the function
bool Process::operator<(Process const& a[[maybe_unused]]) const {
      return a.CpuUtilization() < this->CpuUtilization();
}